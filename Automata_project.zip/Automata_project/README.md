# Automata_project Spring 2023
# Writing  a java – C++ or C# program to 
# 1- convert any non-deterministic finite automaton to deterministic finite automaton
# 2- convert context free grammar to Pushdown automaton 
