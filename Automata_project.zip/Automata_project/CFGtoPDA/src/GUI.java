import java.io.File;

public class GUI {


    //DOT dot;
   // public void toDOT(PDAGraph pdaGraph) {
 //   }
    //public void toGraph(DOT dot) {
//        GraphViz gv = new GraphViz();
//        gv.addln(gv.start_graph());
//        gv.addln("A -> B;");
//        gv.addln("A -> C;");
//        gv.addln(gv.end_graph());
//        String type = "gif";
//        File out = new File("D:/out." + type);
//        gv.writeGraphToFile(gv.getGraph(gv.getDotSource(), type), out);
   // }
}
