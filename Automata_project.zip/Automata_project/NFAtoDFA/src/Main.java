public class Main {

    public static void main(String[] args) {

        Convert_to_DFA DFA = new  Convert_to_DFA();
        DFA.generate_nfa();
        DFA.process_input();



    }

}
